List<dynamic> doctor = [
  'DoctorImg/doctor_1.png',
  'DoctorImg/doctor_1.png',
  'DoctorImg/doctor_1.png',
  'DoctorImg/doctor_1.png',
];
