class Myconst {
  static const int appId = 1659577707;
  static const String appSign =
      'c6b055bab39e7d35a64f3ab568ca11be940665f9e301637330c3b56752b41fa8';
}
